#include <stdio.h>
#include <sc1.h>

int sum = (N*(1+N*N))/2, Count[N*N+1];

struct T{
	int x, y;
}

//Checks if what we have is a valid 
bool validate(){
	int i,j,k;

	for(i=0;i<N;i++){
	//Check rows
		for(j=k=0;j<N;j++){
			k+=s[i][j];
		}
		if(k!=sum)return false;
	//Check columns
		for(j=k=0;j<N;j++){
			k+=s[j][i];
		}
		if(k!=sum)return false;
	}
	//Check diagonals
	for(i=j=k=0;i<N;i++){
		j+=s[i][i];
		k+=s[i][N-(i+1)];
	}
	if((j!=sum)||(k!=sum))return false;

	//Check count
	for(i=0;i<=(N*N);i++)Count[i]=0;
	for(i=0;i<x.size();i++)Count[x[i]]++;
	for(i=1;i<=(N*N);i++)if(Count[x[i]]==0)return false;
	
	return true;
}

//Gaussian Elimination
bool solve(int arr[][N]){

	//Check if no. of equations >= no. of variables

	//Form matrix


}

//Naive bruteforce
int Count[N*N+1];
bool solve1(int arr[][N]){

	int i,j;
	for(i=0;i<=(N*N);i++)Count[i]=0;
	if(solve(arr)==true) 			

}

void calc(){
	
	solve1(s);
	//solve2()
}

int main(){

	int i;
	scanf("%d", &i);
	while(i--){
		input(s);
		calc();
		if(validate())output(s);
		else printf("Output Invalid\n");
	}
	return 0;
}